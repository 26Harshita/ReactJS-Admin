const SubcatagoryData = [
    {Srno: 0, FullName: 'Manjunath R',Email:'manju72nath@gmail.com', PhoneNumber:'7259632496',CreatedDate: '2021/04/30', status: 'Active', Action: ''},
    
    
  ]
  
  
  export default SubcatagoryData
  