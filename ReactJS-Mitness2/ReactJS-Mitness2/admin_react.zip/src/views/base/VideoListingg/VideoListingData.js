const usersData = [
    {Exercise_Name: 'Push Up', Featured_Image: 'img', Exercise_Duration:' 12 days'},
    
  
  ]
  
  export default usersData
  