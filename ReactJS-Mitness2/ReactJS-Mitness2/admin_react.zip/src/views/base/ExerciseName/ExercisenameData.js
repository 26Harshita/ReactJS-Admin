const usersData = [
    {Program_Category: 'Workout', FreeOrPaid: 'Free', Instructor:'Ravi'},
    {Program_Category: 'Dance', FreeOrPaid: 'paid', Instructor:'Umar'},
    
  
  ]
  
  export default usersData
  