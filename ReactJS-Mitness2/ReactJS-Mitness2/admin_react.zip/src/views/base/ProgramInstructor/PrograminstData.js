const ProgramInstructorData = [
    {Srno: 0, FullName: 'Manjunath R',Email:'manju72nath@gmail.com', PhoneNumber:'7259632496',CreatedDate: '22000', packages: '12020', Action: ''},
    
    
  ]
  
  
  export default ProgramInstructorData
  