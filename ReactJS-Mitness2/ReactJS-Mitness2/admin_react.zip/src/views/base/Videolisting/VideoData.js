const usersData = [
    {Program_Name: 'workout', Featured_Image: 'img',Program_Description:'Its about workout', Program_duration:'6 Months',Total_Exercises: '10', Program_Price: '13000'},
    
  
  ]
  
  export default usersData
  