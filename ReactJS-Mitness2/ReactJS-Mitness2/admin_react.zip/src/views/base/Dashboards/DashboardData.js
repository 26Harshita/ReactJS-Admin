const catagoryData = [
    {slno: 0, subcatagory: 'Kushal', maincatagory: '2021/04/27', video: 'Instructor', package: 'Active',action:'',newreg:'User Trainer'},
    
    
  ]
  
  
  export default catagoryData