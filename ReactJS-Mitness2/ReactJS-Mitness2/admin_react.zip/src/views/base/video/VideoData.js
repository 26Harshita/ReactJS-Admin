const VideoData = [
  {slno: 1, FullName: 'Manjunath R',Email_ID:'manju72nath@gmail.com', Phone_Number:'7259632496',Created_Date: '2021/04/30', Status: 'Active', Actions: ''},

    
  ]
  
  
  export default VideoData
  