const TrainerData = [
    {slno: 1, Full_Name: 'Omakar',Email_ID:'Omakar@gmail.com', Phone_Number:'7259632496',Created_Date: '2021/04/30', status: 'Pending', Action: ''},
    {slno: 2, Full_Name: 'Adithya',Email_ID:'Adithya@gmail.com', Phone_Number:'7259632496',Created_Date: '2021/04/30', status: 'Inactive', Action: ''},
    {slno: 3, Full_Name: 'Priyanka',Email_ID:'Priyanka@gmail.com', Phone_Number:'7259632496',Created_Date: '2021/04/30', status: 'Active', Action: ''},
    {slno: 4, Full_Name: 'Kushal P M',Email_ID:'Kushal@gmail.com', Phone_Number:'7259632496',Created_Date: '2021/04/30', status: 'Banned', Action: ''},
    
    
  ]
  
  
  export default TrainerData
  