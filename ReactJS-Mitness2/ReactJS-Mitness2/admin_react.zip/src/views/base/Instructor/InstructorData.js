const instructorData = [
    {id: 0, name: 'Kushal', registered: '2021/04/27', role: 'Instructor', status: 'Active'},
    {id: 1, name: 'Adithya', registered: '2021/04/28', role: 'Instructor', status: 'Active'},
    {id: 2, name: 'Raja', registered: '2021/02/01', role: 'Instructor', status: 'Active'},
    {id: 3, name: 'Priyanka', registered: '2021/02/01', role: 'Instructor', status: 'InActive'},
    
  ]
  
  
  export default instructorData