const catagoryData = [
    {SRno: 0, subcatagory: 'Kushal', maincatagory: '2021/04/27', video: 'Instructor', package: 'Active',action:''},
    
    
  ]
  
  
  export default catagoryData