import React,{Component} from 'react'



export default class Adminprofile extends Component{
    render(){
        return(
            <div>
               <div style={{textAlign:"center",fontSize:"20px",fontFamily:"monospace"}}><u> Admin Profile</u> </div> 
               <br/>
              <center><div  > <img style={{width:"100px",height:"100px"}} src="./avatars/admin.png"/></div></center>
                </div>
        )
    }
}