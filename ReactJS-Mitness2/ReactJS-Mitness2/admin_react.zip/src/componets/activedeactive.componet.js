import React,{Component} from 'react';
export default class Active extends Component{
    render()
    {
        return(
            <div>welcome</div>
        )
    }
}